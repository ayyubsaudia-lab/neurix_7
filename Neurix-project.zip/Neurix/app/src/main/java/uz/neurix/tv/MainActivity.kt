package uz.neurix.tv

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var grid: GridLayout
    private lateinit var status: TextView
    private val dp get() = resources.displayMetrics.density

    // nomi, paket nomlari (o'rnatilgani ochiladi), yo'q bo'lsa Play Store'dagi id
    private val quick = listOf(
        Triple("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), "com.google.android.youtube.tv"),
        Triple("Chrome", listOf("com.android.chrome"), "com.android.chrome"),
        Triple("Google Play", listOf("com.android.vending"), "com.android.vending"),
        Triple("Netflix", listOf("com.netflix.ninja", "com.netflix.mediaclient"), "com.netflix.ninja"),
        Triple("Minecraft", listOf("com.mojang.minecraftpe"), "com.mojang.minecraftpe")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        animatedBackground()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((48 * dp).toInt(), (32 * dp).toInt(), (48 * dp).toInt(), (16 * dp).toInt())
        }
        val title = TextView(this).apply {
            text = "NEURIX"; textSize = 34f; setTextColor(Color.parseColor("#7DE3FF"))
            letterSpacing = 0.3f; typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        status = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#B9A6FF")) }
        grid = GridLayout(this).apply { columnCount = 5 }
        col.addView(title); col.addView(status); col.addView(ScrollView(this).apply { addView(grid) })
        root.addView(col)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); build() }

    private fun build() {
        grid.removeAllViews()
        quick.forEach { (name, pkgs, store) ->
            val installed = pkgs.firstOrNull { isInstalled(it) }
            tile(name, installed?.let { iconOf(it) }, "▶") {
                if (installed != null) launch(installed) else openStore(store, name)
            }
        }
        tile("WiFi", null, "📶") { openFirst(Settings.ACTION_WIFI_SETTINGS) }
        tile("Bluetooth", null, "🔵") { openFirst(Settings.ACTION_BLUETOOTH_SETTINGS) }
        tile("Sozlamalar", null, "⚙️") { openFirst(Settings.ACTION_SETTINGS) }
        tile("Tarmoq", null, "🌐") { openFirst(Settings.ACTION_WIRELESS_SETTINGS) }
        tile("Ekran", null, "🖥️") { openFirst(Settings.ACTION_DISPLAY_SETTINGS) }
        tile("Ovoz", null, "🔊") { openFirst(Settings.ACTION_SOUND_SETTINGS) }
        tile("Til", null, "🗣️") { openFirst(Settings.ACTION_LOCALE_SETTINGS) }
        tile("Sana/Vaqt", null, "🕒") { openFirst(Settings.ACTION_DATE_SETTINGS) }
        tile("Klaviatura", null, "⌨️") { openFirst(Settings.ACTION_INPUT_METHOD_SETTINGS) }
        tile("Xotira", null, "💾") { openFirst(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        tile("Ilovalar", null, "📦") { openFirst(Settings.ACTION_APPLICATION_SETTINGS) }
        tile("Maxfiylik", null, "🔒") { openFirst(Settings.ACTION_PRIVACY_SETTINGS) }
        tile("Qurilma haqida", null, "ℹ️") { openFirst(Settings.ACTION_DEVICE_INFO_SETTINGS) }
        tile("Kesh tozalash", null, "🧹") { cleanCache() }
        tile("Virus tekshiruv", null, "🛡️") { scan() }

        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0) +
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER"), 0)
        apps.distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { ri ->
                val pkg = ri.activityInfo.packageName
                tile(ri.loadLabel(pm).toString(), ri.loadIcon(pm), null) { launch(pkg) }
            }
    }

    private fun tile(label: String, icon: Drawable?, emoji: String?, onClick: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            isFocusable = true; isClickable = true
            background = bg(false)
            setOnClickListener { onClick() }
            setOnFocusChangeListener { v, f ->
                v.background = bg(f)
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(150).start()
            }
        }
        if (icon != null) box.addView(ImageView(this).apply { setImageDrawable(icon) },
            LinearLayout.LayoutParams((64 * dp).toInt(), (64 * dp).toInt()))
        else box.addView(TextView(this).apply { text = emoji ?: "•"; textSize = 36f; gravity = Gravity.CENTER })
        box.addView(TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; maxLines = 1
        })
        val lp = GridLayout.LayoutParams().apply {
            width = (170 * dp).toInt(); height = (120 * dp).toInt(); setMargins(12, 12, 12, 12)
        }
        grid.addView(box, lp)
    }

    private fun bg(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = 24 * dp
        setColor(if (focused) Color.parseColor("#553C8BFF") else Color.parseColor("#33FFFFFF"))
        setStroke(if (focused) 3 else 1, if (focused) Color.parseColor("#7DE3FF") else Color.parseColor("#44FFFFFF"))
    }

    /** Animatsiyali fon: ranglar cyan <-> binafsha oralig'ida silliq almashadi */
    private fun animatedBackground() {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#080818"), Color.parseColor("#1A1245")))
        root.background = g
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 8000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                val t = it.animatedValue as Float
                g.colors = intArrayOf(
                    blend(Color.parseColor("#080818"), Color.parseColor("#0B2A4A"), t),
                    blend(Color.parseColor("#1A1245"), Color.parseColor("#3A1A6B"), t))
            }
            start()
        }
    }

    private fun blend(c1: Int, c2: Int, t: Float) = Color.rgb(
        (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * t).toInt(),
        (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * t).toInt(),
        (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * t).toInt())

    private fun isInstalled(pkg: String) = try { packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }
    private fun iconOf(pkg: String) = try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

    private fun launch(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else toast("Ochilmadi: $pkg")
    }

    private fun openStore(id: String, name: String) {
        toast("$name o'rnatilmagan — Google Play ochilmoqda")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$id"))) }
        catch (e: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$id"))) }
            catch (e2: Exception) { toast("Google Play topilmadi. $name APK sini qo'lda o'rnating.") }
        }
    }

    private fun openFirst(action: String) {
        try { startActivity(Intent(action)) }
        catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { toast("Bu sozlama ushbu qurilmada yo'q") }
        }
    }

    private fun cleanCache() {
        var freed = 0L
        listOfNotNull(cacheDir, externalCacheDir).forEach { d ->
            freed += d.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
            d.deleteRecursively(); d.mkdirs()
        }
        toast("Neurix keshi tozalandi (${freed / 1024} KB). Boshqa ilovalar uchun: Ilova -> Keshni tozalash.")
        openFirst(Settings.ACTION_APPLICATION_SETTINGS)
    }

    /** Google Play'dan tashqari o'rnatilgan ilovalarni topadi (haqiqiy antivirus emas) */
    private fun scan() {
        val pm = packageManager
        val suspicious = pm.getInstalledApplications(0).filter { ai ->
            (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && ai.packageName != packageName &&
            try {
                val src = if (android.os.Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(ai.packageName).installingPackageName
                          else @Suppress("DEPRECATION") pm.getInstallerPackageName(ai.packageName)
                src != "com.android.vending"
            } catch (e: Exception) { false }
        }
        if (suspicious.isEmpty()) { toast("Gumonli ilova topilmadi ✅"); return }
        val names = suspicious.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Google Play'dan tashqari o'rnatilganlar (bosing — o'chirish)")
            .setItems(names) { _, i ->
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${suspicious[i].packageName}")))
            }
            .setNegativeButton("Yopish", null).show()
    }

    private fun toast(s: String) { status.text = s; Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
}
