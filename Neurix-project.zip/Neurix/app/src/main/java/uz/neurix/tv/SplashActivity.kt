package uz.neurix.tv

import android.animation.*
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView

class SplashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#080818")) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.neurix_logo)
            alpha = 0f; scaleX = 0.6f; scaleY = 0.6f
        }
        val size = (resources.displayMetrics.heightPixels * 0.7).toInt()
        root.addView(logo, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        setContentView(root)

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f),
                ObjectAnimator.ofFloat(logo, "scaleX", 0.6f, 1f),
                ObjectAnimator.ofFloat(logo, "scaleY", 0.6f, 1f)
            )
            duration = 1500
            start()
        }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2800)
    }
}
