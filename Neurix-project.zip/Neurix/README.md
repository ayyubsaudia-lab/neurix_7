# Neurix TV Launcher
1. Android Studio -> Open -> shu papka (Neurix).
2. Gradle sync tugashini kuting.
3. Build -> Build APK(s). Natija: app/build/outputs/apk/debug/app-debug.apk
4. Televizor/boksga o'rnatish: USB flesh yoki `adb install app-debug.apk`.
